package interfaz;

import gui.menuPrincipal;


public class Interfaz {

    public static void main(String[] args) {
       menuPrincipal menu = new menuPrincipal();
       
       
       menu.setVisible(true);
       menu.setLocationRelativeTo(null);
    }
}

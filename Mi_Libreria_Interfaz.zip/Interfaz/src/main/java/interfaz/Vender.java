package interfaz;

public class Vender {
    private String nombre, apellido;
    private int cedula, cantidadVendido;
    private double montoFinal;

    public Vender(String nombre, String apellido, int cedula, int cantidadVendido, double montoFinal) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.cantidadVendido = cantidadVendido;
        this.montoFinal = montoFinal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public int getCantidadVendido() {
        return cantidadVendido;
    }

    public void setCantidadVendido(int cantidadVendido) {
        this.cantidadVendido = cantidadVendido;
    }

    public double getMontoFinal() {
        return montoFinal;
    }

    public void setMontoFinal(double montoFinal) {
        this.montoFinal = montoFinal;
    }
    
    

    @Override
    public String toString() {
        return "RECIBO\n\n" + "Nombre: " + nombre + "\nApellido: " + apellido + "\nCedula: " + cedula + "\nLibros Vendida: " + cantidadVendido + "\n\nTOTAL: " + montoFinal + '$';
    }

   
    
    
    
}
